package com.marolix.Bricks99.entity;

public enum SellerStatus {
APPROVED,PENDING,REJECTED
}
